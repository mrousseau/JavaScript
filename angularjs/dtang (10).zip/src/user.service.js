const api = 'http://localhost:3000/users';

export class UserService {
    constructor($http) {
        this.$http = $http;
    }

    getUsers() {
        return this.$http.get(api)
            .then(response =>  response.data);
    }

    addUser(user) {
        return this.$http.post(api, user)
            .then(response =>  response.data);
    }
}